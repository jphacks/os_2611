# 工作梳理与能力推荐原型（产品名称未定）

面向日本市场，在现有 coding 软件中，帮助用户逐步找到适合自己工作和学习的 AI 工具与 agent。
先介绍使用逻辑，检查实际记忆、电脑和工具，必要时补问具体信息，再调查、推荐和按选择继续。
不要求学习 AI 技术；用户可自行定制、开发或接入其他工作流。
没有独立模型或账号。工作者可用自己的常用语言交流。

## 使用

聊天交接入口为完整自包含的 `START.md`。附上它并明确说“使用这个工作助手，直接开始”。
它不依赖相邻文件，但不创建后台服务或冒充已安装程序。普通聊天窗口没有的记忆、
电脑访问与联网能力仍不可用，必须如实说明。原有coding宿主仍可使用整个项目和脚本。
先查记忆、电脑配置、已安装与常用工具的实际证据，随后自行验证具体延伸方案，最后
征询用户对具体方案的意见。`environment.py`仅收集当前运行环境的有限只读元数据，
不扫描软件活动历史，不把安装等同于常用，不把远端沙箱当作用户电脑。

分享整个ZIP，不要只发START.command。若用户已在coding软件中对话，直接让宿主
读取包内app/AGENTS.md并开始体验，不要运行启动器再嵌套打开另一个对话。
宿主没有提供的记忆无法凭同一账号跨产品读取；首轮应检查实际记忆入口并如实反馈。

Mac测试包：解压后，双击`START.command`，在打开的新对话点一次发送。
同一个入口自动检测 Codex 与 Claude Code CLI；只有一个时自动使用，两个都有时选择一次并记住。
首次跟随系统语言，随后跟随对话语言；分发包不包含制作者个人记录。
目录和首条指令由启动器自动填写，不需要用户阅读项目文件或复制长提示词。
统一入口不安装软件、不修改全局设置或跳过授权；需已装相应宿主与Python 3。
Codex入口使用官方的path和prompt启动链接，只预填消息，不自动发送。
启动机制已做本地验证；真实应用内的打开和首次回答仍需真人确认，不用单元测试冒充实机通过。

开发者或其他平台也可按下列方式启动：

让 Codex 打开这个目录，输入：

> 请读 AGENTS.md，帮我梳理最近的工作。一次只问必要的问题，先不要安装工具。

也可在当前对话指定 `.agents/skills/work-intake/SKILL.md` 的完整路径。
Skill 是否出现在宿主菜单里取决于该宿主的项目 Skill 发现机制；本原型不冒充已全局安装。

Codex和Claude Code共用同一套核心程序。Codex入口为`AGENTS.md`和`.agents/skills`；
Claude Code入口为`CLAUDE.md`和`.claude/skills`，后者只转入同一份核心流程。
无需复制两套逻辑、注册本产品账号或配置额外模型API。实际搜索与权限取决于当前宿主。
同一目录共用用户确认保存的记录，分别解压则相互独立。示例中的Codex能力不能当作
Claude Code当前能力的证据。Claude入口与本地脚本路径已校验，Claude应用内真人测试待完成。
其他支持本地读文件和Python 3的Coding Agent可以显式读取AGENTS.md试用，未声称自动适配。

Claude入口依据官方文档：[项目Skills](https://code.claude.com/docs/en/skills)、
[项目指令导入](https://code.claude.com/docs/en/memory)，核查日期2026-10-17。

自然语言交互由宿主模型完成。Python 脚本只保存、校验和比较状态，不会自己理解自然语言。

## 实现范围

- 每次最多三个必要问题，一次一个；信息够用即可停止。
- 启动先读已保存的本地画像，再使用宿主已提供的相关工作记忆；已有信息不重复询问。
  当前明确陈述优先于旧记忆。记忆临时参与本轮判断，不会自动落盘或进入公开搜索词。
- 画像以用户确认的简短描述保存，不默认保存原始对话。
- 用户可查看、纠正、忘记指定内容、清空、暂停和恢复。
- 拒绝保存时，仍可完成本次临时梳理。
- 输出跟随用户语言；不做能力评分、心理推断或雇主监控。
- 已有按岗位／学生背景的公开调查 Skill；搜索使用宿主工具。
- 不自建后台监控或调度服务。软件连接与定期汇报由宿主真实能力完成：先提具体范围、取得选择，再执行并核对结果；无接口时明确未启用。

## 数据与费用

仅在用户同意保存后，创建 `.private/state.json`（目录 0700，文件 0600）。
它被 Git 忽略，但**不是加密数据库**，也无法控制系统备份或宿主聊天历史。
本地保存不等于离线推理：用户消息和读取的画像可能由现有宿主发送给云端模型。
脚本无网络调用；模型使用消耗宿主原有额度。

画像脚本只访问本项目固定记录目录；只读环境检测检查有限的系统元数据和标准应用位置。
暂不支持团队共享或多用户共用一份状态。
本地变更记录只保留时间和变化字段名，不保留旧回答；最多 20 条。
清空本地状态不能删除宿主对话和外部备份。

## 一轮体验

用户：每次开完会都要把聊天里的决定搬进项目表，来回复制很烦。

助手应当识别到任务与困难已经明确，直接整理理解，并建议先把已确认决定
生成一份待核对的清单。无需继续询问职级、雇主、年龄或完整履历。
若不知道项目表的格式确实会影响下一步，可问一个具体问题。

用户：不要保存。

助手应继续提供临时建议，不能创建个人记录。用户明确允许记录哪些点后，
只保存这些点。再次使用时应从记录继续，而非重新进行完整入门问卷。

控制语句：你记住了什么／改一下我的目标／忘掉那项／暂停／恢复。
这些由宿主理解后调用本地接口。涉及删除时遵循宿主的确认要求。

## 状态接口（供 Coding Agent 使用）

通过 stdin 提交一个 JSON 对象，避免在命令行参数暴露个人回答：

`python3 .agents/skills/work-intake/scripts/intake.py`

- `{"action":"status"}`：读取状态；无文件时返回空画像，不写磁盘。
- `{"action":"assess","questions_asked":0,"memory_status":"checked","profile":{"tasks":"整理报告"}}`：完成实际记忆检查后判断是否需要具体补问；有活动信息就直接继续，不保存输入，不要求自诊断痛点。
- `{"action":"apply","expected_revision":0,"confirmed":true,"profile":{"role":"设计师"}}`：保存已确认字段。
- `{"action":"forget","expected_revision":1,"confirmed":true,"fields":["role"]}`：移除指定字段。
- `pause` / `resume`：同样要求版本与确认；暂停时禁止 apply。
- `reset`：同样要求版本与确认；清空画像与变更记录，保持版本递增。

允许的画像字段：`role, context, goals, tasks, friction, tools, constraints,
output_preferences, language, work_style, organization, sector, department, major,
year`，值为最多 2000 字符的非空文本。
错误输出是供宿主读取的结构化代码；宿主必须将其解释为自然语言。
版本冲突时先重新读取，禁止静默覆盖。失败时不自动扩大权限。

问卷可以按需使用，但不能重复劳动、无效填表或断层交流。先检索；缺少会影响当前结果的具体信息才问，回答马上用于调查和建议。学校/专业、公司/行业、岗位与日常任务均可具体补问，资料充分就直接给初步推荐。
`assess` 默认先返回 `recall`，宿主必须先检查记忆入口，再提供真实的 `memory_status`（checked/unavailable/disabled）。日常任务已知就直接继续。确需补问时返回 ask；信息不足且问题已问/被拒或不再有帮助时，使用已有背景或明确标注的示例。friction不是必要字段。

`needed_fields`仅列当前结果必需的具体字段（默认tasks）；`asked_fields`与`declined_fields`避免重复，已知字段自动跳过。传`needed_fields:[]`可直接用已有背景给初步推荐。字段清单不是完整度问卷，也不自动保存。

`assess` 不会自动推荐某种软件，具体理解与自然语言建议由宿主完成。

`assess`可附`memory:{profile:{...},source:"host_provided"}`，或对用户指定记忆文件使用
`user_authorized_file`。仅传相关工作字段，不传整份聊天和记忆。返回字段来源与冲突，
不写文件；最新明确陈述覆盖旧值，新任务不会直接继承旧任务的困难。

## 测试

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`

使用合成资料与临时目录，不读取真实个人资料。自然语言体验需要另行实测，
通过存储单元测试不等于已验证宿主交互或安全授权弹窗。

## 公开环境调查

主 Skill 为 `.agents/skills/work-context/SKILL.md`。先选择与用户有关的公开信息，
再交给宿主执行搜索与阅读；本地 `scripts/research.py` 负责计划、结构校验、
可选本地保存和前后比较，无第三方依赖或额外模型调用。

自然语言入口：

> 我是日本公司的普通事务职员，想减少资料重复填写。请先调查与这项工作有关的公开资料。

> 我在某大学学某专业。请查一下公开专业介绍，帮助你理解背景，但不要当作我的实际课程安排。

默认不看财报。即使用户是管理者，也只有具体任务需要时才调查财务。
保留直接相关、相邻影响、限制或反证、覆盖盲区；官方宣传不能代替个人确认。
搜索时只发送必要的公开主题，个人原始问卷不会被自动拼入搜索词。

接口（JSON stdin，python3 运行该 Skill 的 `scripts/research.py`）：

- `plan`：`context` 含 audience、可选 organization/sector/role/major/topics/financial_context_required。
  audience 支持 worker/student/freelancer/manager/owner/general。
- `validate`：提交 `report`，核查来源 ID、日期和结构；不宣称证据已由程序验证。
- `compare`：提交 `report`，与上次保存版本比较，不写文件。
- `status`：读取最新保存的情报；没有则返回空。
- `save`：提交 report、confirmed:true、expected_revision；只保留最新版。
- `clear`：confirmed:true、expected_revision，清空该情报记录，保留递增版本。

记录独立保存在 `.private/research.json`，不把外部推断自动写成个人事实。
`examples/` 是 2026-10-17 从官方公开页面核对的示例，无真实个人画像；
示例是一次性背景快照，不是持续更新的情报订阅。

## 会社调查与能力推荐

入口仍是现有 Coding 软件中的一句话：

> 以 JPHACKS 2026 大阪为场景，调查大会会社和适合我们的已有能力，并检查产品是否已有类似实现。

会社调查沿“活动官方资料 → 关系名录 → 公司官方业务／产品 → 方向 → 相关性假设”展开。
能力搜索先检查宿主已有工具，再查官方插件、社区目录和 GitHub。不要求用户为了阅读
公开仓库新建 GitHub 账号；具体服务的账号和费用单独说明。

- `.agents/skills/company-research/`：会社与大会关系、业务、产品和来源核查流程。
- `.agents/skills/find-capabilities/`：能力搜索、相似产品调查、许可证及接入条件核查。
- `find-capabilities/scripts/catalog.py`：只读 JSON 接口；`plan` 输出检索阶段，
  `evaluate` 检查候选证据完整性并按可审阅程度与来源层级排序，`validate_companies`
  检查会社证据包。确切字段见脚本与 `examples/`。

宿主负责实际联网检索、阅读和自然语言解释；这些脚本不会自行联网、安装或执行第三方代码。
结构验证通过不等于证据真实、已通过安全审计或兼容性实测。只有宿主真正试用过的能力
才可标为 tested。账号、费用或兼容性未知时不会标为可直接选择。

`find-capabilities/scripts/recommend.py` 将已核查候选与当前宿主的实际能力放在一起，
按当前任务给出一个默认建议、最多两个备选。任务理解和已启用工具的观察仍由宿主完成；
程序不声称自己理解自然语言或实测了插件。优先复用已有能力，说明只能部分帮助的范围。
需要权限时解释读取范围和数据去向，使用宿主真实授权流程，不生成假的开关。
重要外部结论附原始来源链接；事实、适合度推断与实际执行状态分别显示。

推荐接口输入字段：`action:recommend`、`language`、`task`（summary/desired_output）、
`pool`（完整evaluate请求）、`assessments`（每个候选的任务匹配及证据）、
`available_tools`（宿主当前能力、范围、账号费用和观察记录）。只读，不自动读取个人画像。
可附`preferences`（allow_new_accounts/allow_setup，默认均为false）和
`host_inventory_checked`（默认false）。前者是用户偏好，不等于执行授权；后者需要宿主
真正检查当前能力。未检查已有能力或用户不想增加设置时，只介绍比较候选，不推进接入。
日中常用说明提供本地模板，其他语言由宿主翻译结构化结果，不默认退回英文。
`examples/recommend-*.json` 和 `research/experience-demo-ja.md` 展示实跑方式。

本轮完整场景结果在 `research/jphacks-2026.md`，同类产品与吸收记录在
`research/related-products.md`；所有日期为一次性快照，刷新需重新检索。

## 连接与周期任务的状态核对

`workflow.py`是无副作用的交接状态校验器，不会登录软件或创建任务。宿主先检查真实工具：
发现能力 → 提出具体范围 → 用户选择 → 调用真实接口 → 核对实际回执。
连接回执包含id与connected；周报提案包含topic/schedule/timezone/output_language/source_scope，
创建后回执包含id/enabled/schedule/timezone。没有回执或时间配置不符，不会标记active。
这些回执必须来自宿主实际工具；脚本仅校验结构与一致性，不独立证明外部任务存在。
普通聊天入口START.md同样遵循上述逻辑，但不需要任何Python脚本。
