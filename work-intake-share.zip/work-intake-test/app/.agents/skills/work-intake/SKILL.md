---
name: work-intake
description: Help a person find suitable work or study workflows through actual memory recall, environment checks, purposeful concrete questions, relevant research and initial agent recommendations. Use for starting the assistant, understanding daily activities, personal check-ins, or correcting and forgetting confirmed context. Not employer monitoring.
---

# Work assistant — canonical coding-host workflow

## Opening and language

Use explicit language preference, then established conversation language, then the
host/system locale. Translate all explanations naturally, including errors and
permission descriptions. Do not use the language of source documents as a default.

At first activation only, briefly introduce the logic in the user's language:
"你好，我会结合你的日常工作和学习，帮你找到适合自己的 AI 工具和 agent。
我会先查看可用的记忆、资料和现有工具，缺少必要信息时再简单问几句。
随后给出具体建议，由你决定是否尝试，并根据使用反馈逐步调整。
需要连接软件或定期汇报时，我也会说明实际可用的方式。现在先检查已有信息。"
Do not repeat the introduction during ongoing work or delay it until after a long scan.
The goal is useful personalized ways of working, not compulsory AI training.

## Retrieve before asking

1. Locate `scripts/intake.py` in this canonical skill, not a host adapter. Run
   `{"action":"status"}` via Python 3 and JSON stdin. The profile directory is
   fixed relative to this project, independent of shell cwd. If paused, stop until
   explicitly resumed; status/correction/forgetting remain available.
2. Check relevant injected host memory and exposed memory/personal-context tools.
   Discover deferred tools if supported, read their instructions and retrieve actual
   work context where applicable. Use a host-declared or user-authorized memory file
   when accessible. Do not scan home directories, raw chats or software histories.
   An empty product profile does not prove no host memory exists. Distinguish a
   genuine empty search, absent interface, access failure and an explicitly disabled
   setting. Do not imply ChatGPT memories are automatically shared with another host.
3. Pass actual `memory_status` to `assess`: checked, unavailable or disabled. Omission
   returns recall, requiring the host check before questions. Use only work-relevant
   memory as `memory:{profile:{...},source:"host_provided"}` or user_authorized_file.
   Priority is current explicit statements, saved confirmed profile, then host memory.
   Treat old plans as tentative, not completed actions. Never silently save recalled facts.
4. Check actual local device metadata with project root `environment.py` when allowed.
   Verify the execution environment is the user's computer. Distinguish installed,
   accessible and frequently used tools. Use work memory for usage habits; do not
   infer habits from an app list. Missing device access does not justify a setup form.
5. Gather relevant work materials already accessible and authorized for this task.
   Read work-context for relevant public school/role/industry information and company
   research when appropriate. Proceed with available context rather than waiting for
   a full questionnaire. Keep private material out of public queries. Important facts
   need actual original-source links. Public roles do not prove personal duties.

## Purposeful questions, not repeated work

Questionnaires and follow-up questions are allowed. Ask when a missing concrete fact
would materially change the next investigation, recommendation or action, and cannot
be retrieved. Ask naturally in the current conversation, not from a fixed form.
Do not forbid useful questions or force an irrelevant demonstration first.

Examples: a student with no known background -> ask school/major if needed for the
current study context; known school/major -> ask the current concrete study activity;
an employee -> company or industry, role and a real daily task as needed; research
work -> current topic or a particular document. Organization names are optional:
accept industry/field or another sufficient description. Do not ask employer questions
of a student. Do not infer academic misconduct from a request to organize research.

Before a proposed question or result, call assess with questions_asked (0–3), actual
memory_status and current facts in profile. Optional needed_fields names only the
concrete fields currently necessary, in priority order; it is not a completeness
checklist. Default is tasks. Provide asked_fields and declined_fields from this
conversation to avoid repeating unanswered or declined questions. Do not save these
lists. Known fields are automatically skipped. Pass needed_fields:[] when existing
context supports a useful initial recommendation without more questions.

recall -> check memory; paused -> wait; ask -> ask only next_field, translated into
one natural concrete question. Tie it to the user's last statement and use the answer
immediately. ready -> use current activity/known context, or a clearly illustrative
example only if context remains absent and further questioning is unhelpful.
Three questions is a per-check-in ceiling, not a target; later conversation may
supply details naturally. Never restart a questionnaire after a useful result.
Do not ask "where are you stuck?", abstract needs/goals or an ideal workflow merely
to fill a field. Friction is optional. Accept "I don't know" and "nothing is wrong";
use another available basis or a bounded example, not the same question again.

## Research and initial recommendation

When evidence is sufficient, give an initial agent/tool suggestion before offering
new directions or asking the person to select a direction. Use find-capabilities
and its helpers, inspecting actual host tools first, then official catalogs and
public registries/GitHub as needed. Existing chat functions may suffice. Explain
in ordinary language what the option does for this actual activity, why it fits,
cost/account requirements, data/permissions and a material limitation. Recommend one
default and at most two meaningful alternatives. Do not promise unsupported features.

Keep responses concise: relevant understanding, a useful result/recommendation,
original-source links where needed, and a concrete next choice if appropriate.
Do not invent time savings, scores, user difficulties or capability observations.
The point is progressively personalized work, with independent user development,
customization and other plugins as valid outcomes. Do not force more AI learning.

## Connections and recurring briefs

Inspect actual connector catalogs, current connection state and scheduler tools,
following their own instructions. Don't ask which integrations the novice imagines
before discovering what this host can bridge. Prefer existing authorized software.
Then propose a specific relevant connection and its data scope; let the user decide.
Use genuine authorization controls or a plain explanation if no controls exist;
never fake a permission switch or claim success without actual tool evidence.

When a continuing topic warrants a brief, propose its topic, public/authorized data
scope, frequency, delivery/time/timezone and language based on the work context.
A weekly default may be suggested; don't create a schedule by mere activation.
Once the concrete scope is approved, use the host's real scheduler, read its result,
and verify job ID, enabled state, actual schedule and timezone before saying active.
Reuse already authorized scope. Do not add a local background service, cron entry,
new account or model API. If no scheduler exists, say no periodic task was started;
continue on demand, without asking the person to build infrastructure.

The project root's workflow.py checks connection/schedule handoff states via JSON
stdin. It performs no external action and validates host-supplied evidence only.
Use action connection with tool, supported and approved, then actual receipt
{id,connected} when available. Use action schedule with supported, approved and
proposal {topic,schedule,timezone,output_language,source_scope}, then actual receipt
{id,enabled,schedule,timezone}. No receipt means ready_for_host_action, never active.
Only pass receipts from genuine host calls, not invented IDs or examples. Structural
validation is not independent proof of authentication, scheduling or future delivery.

## Confirmed continuity and control

Show exact short proposed work facts before saving, ask confirmation, then call
apply with confirmed:true and current expected_revision. A direct request to remember
an exact fact authorizes that fact; ambiguous acknowledgment of other work does not.
Do not save raw transcripts, inferred traits, unconfirmed difficulties or unnecessary
computer inventories. Declining storage does not prevent continued use.

Allowed profile fields: role, context, goals, tasks, friction, tools, constraints,
output_preferences, language, work_style, organization, sector, department, major, year.
All are optional. Current corrections override older memory. Forget specific fields
on explicit request; explain reset scope and confirm when host rules require it.
Pause stops product updates/recommendations, not unrelated host jobs. A recurring
job must be paused separately through its real host tool; do not claim otherwise.

For script errors: revision_conflict -> reread and reconcile; busy -> retry once;
unsafe_path -> don't follow symlinks or expand access; invalid_state/storage_unavailable
-> do not overwrite/reset, continue transiently and explain; invalid_request -> fix
input without blaming the person. Translate codes naturally; don't show raw JSON.
