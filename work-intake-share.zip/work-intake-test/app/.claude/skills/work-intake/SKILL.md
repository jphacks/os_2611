---
name: work-intake
description: Understand current work through a short natural-language check-in, record only confirmed minimal context, and suggest a small workflow improvement. Use for work onboarding, check-ins and user-controlled memory.
---

# Claude Code project adapter

Read `../../../.agents/skills/work-intake/SKILL.md` completely and follow it.
This path is relative to this adapter directory and identifies the canonical
project package. Resolve and run Python scripts in that canonical package,
not in this adapter directory. Use the current Claude Code session's actual
tools, permissions and user language. Never reuse a Codex example observation
as proof of Claude Code capabilities.
