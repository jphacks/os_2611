﻿$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
function Show([string]$message) { [Console]::Error.WriteLine($message) }
function CommandExists([string]$name) {
  $cmd = Get-Command $name -ErrorAction SilentlyContinue | Select-Object -First 1
  return ($null -ne $cmd -and $cmd.CommandType -in @('Application', 'ExternalScript'))
}
$hosts = @()
$codexLink = (Test-Path 'Registry::HKEY_CURRENT_USER\Software\Classes\codex') -or (Test-Path 'Registry::HKEY_CLASSES_ROOT\codex')
$codexApp = $false
try { $codexApp = $null -ne (Get-StartApps -ErrorAction Stop | Where-Object { $_.AppID -eq 'OpenAI.Codex_2p2nqsd0c76g0!App' -or $_.Name -match '^(OpenAI )?Codex$' } | Select-Object -First 1) } catch { }
if ($codexLink -or $codexApp -or (CommandExists 'codex')) { $hosts += [pscustomobject]@{ Label='Codex'; Id='codex' } }
$claudeDesktop = $false
$claudeLink = (Test-Path 'Registry::HKEY_CURRENT_USER\Software\Classes\claude') -or (Test-Path 'Registry::HKEY_CLASSES_ROOT\claude')
try { $claudeDesktop = $null -ne (Get-StartApps -ErrorAction Stop | Where-Object { $_.Name -match '^Claude( Desktop)?$' } | Select-Object -First 1) } catch { }
$claudeCli = CommandExists 'claude'
Show ('Claude Desktop の登録: ' + $claudeDesktop + '; Claude Code CLI: ' + $claudeCli + '; Desktop の Code セッションは開くまで未確認です。')
if ($claudeCli -or ($claudeLink -and $claudeDesktop)) { $hosts += [pscustomobject]@{ Label='Claude Code'; Id='claude' } }
if (CommandExists 'gemini') { $hosts += [pscustomobject]@{ Label='Gemini CLI'; Id='gemini' } }
if ($hosts.Count -eq 0) {
  Show '対応する AI が見つかりません。Codex、Claude Code、または Gemini CLI にサインインしてから、もう一度 START を実行してください。'
  exit 2
}
if ($hosts.Count -eq 1) {
  Show ('使えるホストは 1 つです: ' + $hosts[0].Label)
  [Console]::Out.WriteLine($hosts[0].Id)
  exit 0
}
Show ('Work Intake - 使える AI が ' + $hosts.Count + ' 個あります:')
for ($i=0; $i -lt $hosts.Count; $i++) { Show ('[' + ($i+1) + '] ' + $hosts[$i].Label) }
Show ('今すぐ 1-' + $hosts.Count + ' を押してください。15 秒間選ばないと [1] ' + $hosts[0].Label + ' を選びます。')
$timer = [Diagnostics.Stopwatch]::StartNew()
$last = -1
$keyboardAvailable = $true
while ($timer.Elapsed.TotalSeconds -lt 15) {
  $remaining = [Math]::Ceiling(15 - $timer.Elapsed.TotalSeconds)
  if ($remaining -ne $last) { Show ("[1] を $remaining 秒後に選びます..."); $last = $remaining }
  try {
    if ($keyboardAvailable -and [Console]::KeyAvailable) {
      $key = [Console]::ReadKey($true).KeyChar
      $number = [int][char]$key - [int][char]'0'
      if ($number -ge 1 -and $number -le $hosts.Count) {
        Show ('選択: ' + $hosts[$number-1].Label)
        [Console]::Out.WriteLine($hosts[$number-1].Id)
        exit 0
      }
      Show '番号が違います。カウントダウンを続けます。'
    }
  } catch { Show 'ここではキーボードを使えません。既定のホストを待ちます。'; $keyboardAvailable = $false }
  Start-Sleep -Milliseconds 75
}
Show ('時間切れです。[1] ' + $hosts[0].Label + ' を選びます。')
[Console]::Out.WriteLine($hosts[0].Id)
