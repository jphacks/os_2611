# Product protocol

Work Intake is an instruction-only, host-native AI capability discovery Skill. The host performs authorized reading, public research, repository/source review, judgment and optional setup. The Skill supplies scope, source and permission standards. It does not create another engine or task database.

Internal context and external reality are interacting evidence sources. A search may reveal a missing internal condition; testing may invalidate a recommendation. Start from existing conversation and relevant materials, not an identity form. Use the user's language, research the actual location and context, and separate confirmed facts from inference. Public names can be searched when relevant; private materials and secrets cannot be placed in public queries.

Inspect usable existing tools first. If a capability gap remains, search trustworthy original sources and evaluate real candidates for fit, compatibility, license, maintenance, dependency, cost, privacy and reversibility. A retrieved repository is only a candidate. Make a concise, source-backed recommendation, which may recommend zero installations. Request permission for changes and verify a real task after integration. An operation receipt is not functional evidence.

User-level installation is a separate bootstrap action. It never opens a session, triggers a Skill, or reads the user's work. Work Intake itself runs in the host conversation only when explicitly invoked or selected by that host.
