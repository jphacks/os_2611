@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "TARGET=%~1"
if "%TARGET%"=="" set "TARGET=codex"
if /I not "%TARGET%"=="codex" if /I not "%TARGET%"=="claude" if /I not "%TARGET%"=="gemini" if /I not "%TARGET%"=="both" (
  echo Usage: INSTALL.cmd [codex^|claude^|gemini^|both]
  exit /b 2
)
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Windows PowerShell was not found. Work Intake was not installed.
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL.ps1" -HostName "%TARGET%"
set "RESULT=%ERRORLEVEL%"
if "%RESULT%"=="0" (
  echo Work Intake Skill files were verified. Host recognition and opening Codex still need to be checked.
) else (
  echo ERROR: Work Intake installation failed. Check the PowerShell error above; no launch was attempted.
)
exit /b %RESULT%
