@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
title Work Intake - START
cd /d "%~dp0"
if not exist "%~dp0INSTALL.cmd" goto not_extracted
if not exist "%~dp0INSTALL.ps1" goto not_extracted
if not exist "%~dp0select-host.ps1" goto not_extracted
if not exist "%~dp0open-host.ps1" goto not_extracted
if not exist "%~dp0.agents\skills\work-intake\SKILL.md" goto not_extracted
echo Work Intake - 使える AI を確認しています。
set "TARGET="
for /f "usebackq delims=" %%H in (`powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0select-host.ps1"`) do set "TARGET=%%H"
if not defined TARGET (
  echo 対応する AI が選ばれませんでした。何もインストールしていません。
  pause
  exit /b 2
)
echo %TARGET% 用に Work Intake をインストールしています。
call "%~dp0INSTALL.cmd" "%TARGET%"
if errorlevel 1 (
  echo インストールが完了しませんでした。既存のファイルは黙って置き換えていません。
  pause
  exit /b 1
)
echo Skill ファイルを確認しました。%TARGET% の会話を開くよう要求しています...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0open-host.ps1" -HostName "%TARGET%"
if errorlevel 1 (
  echo 起動に失敗したか、確認できませんでした。Skill ファイルはインストール済みです。上の理由を読んでください。
  pause
  exit /b 2
)
if /I "%TARGET%"=="codex" (
  echo Codex の起動要求を送りました。チャット画面と Work Intake の応答を確認してください。
) else (
  echo 起動要求を送りました。チャット画面と Work Intake Skill を確認してください。ウィンドウが開いただけでは有効化の証明になりません。
)
exit /b 0
:not_extracted
echo ZIP の中から開かれました。すべて展開してから起動します。
set "WI_LAUNCHER=%~f0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand JAB0ACAAPQAgAEcAZQB0AC0AQwBvAG4AdABlAG4AdAAgAC0ATABpAHQAZQByAGEAbABQAGEAdABoACAAJABlAG4AdgA6AFcASQBfAEwAQQBVAE4AQwBIAEUAUgAgAC0AUgBhAHcACgAkAGEAIAA9ACAAJwAjACMAIwBFAFgAVABSAEEAQwBUACMAIwAjACcACgAkAGIAIAA9ACAAJwAjACMAIwBFAE4ARAAjACMAIwAnAAoAJABpACAAPQAgACQAdAAuAEkAbgBkAGUAeABPAGYAKAAkAGEAKQAKAGkAZgAgACgAJABpACAALQBsAHQAIAAwACkAIAB7ACAAZQB4AGkAdAAgADIAIAB9AAoAJABzACAAPQAgACQAdAAuAFMAdQBiAHMAdAByAGkAbgBnACgAJABpACAAKwAgACQAYQAuAEwAZQBuAGcAdABoACkACgAkAGoAIAA9ACAAJABzAC4ASQBuAGQAZQB4AE8AZgAoACQAYgApAAoAaQBmACAAKAAkAGoAIAAtAGwAdAAgADAAKQAgAHsAIABlAHgAaQB0ACAAMgAgAH0ACgAkAHMAIAA9ACAAJABzAC4AUwB1AGIAcwB0AHIAaQBuAGcAKAAwACwAIAAkAGoAKQAKACQAbABpAG4AZQBzACAAPQAgACQAcwAgAC0AcwBwAGwAaQB0ACAAWwBFAG4AdgBpAHIAbwBuAG0AZQBuAHQAXQA6ADoATgBlAHcATABpAG4AZQAgAHwAIABGAG8AcgBFAGEAYwBoAC0ATwBiAGoAZQBjAHQAIAB7ACAAaQBmACAAKAAkAF8ALgBTAHQAYQByAHQAcwBXAGkAdABoACgAJwBSAEUATQAgACcAKQApACAAewAgACQAXwAuAFMAdQBiAHMAdAByAGkAbgBnACgANAApACAAfQAgAGUAbABzAGUAIAB7ACAAJABfACAAfQAgAH0ACgBJAG4AdgBvAGsAZQAtAEUAeABwAHIAZQBzAHMAaQBvAG4AIAAoACQAbABpAG4AZQBzACAALQBqAG8AaQBuACAAWwBFAG4AdgBpAHIAbwBuAG0AZQBuAHQAXQA6ADoATgBlAHcATABpAG4AZQApAA==
if errorlevel 1 (
  echo 展開できませんでした。ZIP を右クリックしてすべて展開し、展開したフォルダの [Windows] START を実行してください。
  pause
  exit /b 1
)
exit /b 0
###EXTRACT###
REM $ErrorActionPreference = 'Stop'
REM $ProgressPreference = 'SilentlyContinue'
REM $launcher = $env:WI_LAUNCHER
REM if (-not $launcher) { throw 'WI_LAUNCHER is empty' }
REM $dir = Split-Path -Parent $launcher
REM $hint = ''
REM $cursor = $dir
REM while ($cursor) {
REM   $leaf = Split-Path -Leaf $cursor
REM   if ($leaf -match '\.zip$') {
REM     $hint = [regex]::Replace($leaf, '^Temp\d+_', '')
REM     break
REM   }
REM   $parent = Split-Path -Parent $cursor
REM   if (-not $parent -or $parent -eq $cursor) { break }
REM   $cursor = $parent
REM }
REM $names = New-Object System.Collections.Generic.List[string]
REM if ($hint) { [void]$names.Add($hint) }
REM [void]$names.Add('work-intake-0.3.3-Windows.zip')
REM [void]$names.Add('work-intake-0.3.3.zip')
REM function Find-ZipName([string]$root, [string]$name, [int]$depth) {
REM   if ($depth -lt 0) { return }
REM   if (-not (Test-Path -LiteralPath $root)) { return }
REM   foreach ($item in @(Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue)) {
REM     if (-not $item.PSIsContainer) {
REM       if ($item.Name -eq $name) { $item }
REM     } elseif ($depth -gt 0 -and $item.Name -ne 'node_modules' -and $item.Name -ne '.git') {
REM       Find-ZipName $item.FullName $name ($depth - 1)
REM     }
REM   }
REM }
REM $roots = @(
REM   (Join-Path $env:USERPROFILE 'OneDrive\문서\xwechat_files'),
REM   (Join-Path $env:USERPROFILE 'Downloads'),
REM   (Join-Path $env:USERPROFILE 'Desktop'),
REM   (Join-Path $env:USERPROFILE 'Documents'),
REM   (Join-Path $env:USERPROFILE 'OneDrive')
REM )
REM $zip = $null
REM foreach ($name in $names) {
REM   $hits = @()
REM   foreach ($root in $roots) { $hits += @(Find-ZipName $root $name 8) }
REM   $zip = $hits | Sort-Object LastWriteTime -Descending | Select-Object -First 1
REM   if ($zip) { break }
REM }
REM if (-not $zip) { throw 'ZIP not found' }
REM $destRoot = Join-Path $env:USERPROFILE 'WorkIntake'
REM New-Item -ItemType Directory -Force -Path $destRoot | Out-Null
REM $dest = Join-Path $destRoot ('extracted-' + [guid]::NewGuid().ToString('N'))
REM Add-Type -AssemblyName System.IO.Compression.FileSystem
REM if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
REM [System.IO.Compression.ZipFile]::ExtractToDirectory($zip.FullName, $dest)
REM $start = @(Get-ChildItem -LiteralPath $dest -Recurse -Force -File | Where-Object { $_.Name -eq '[Windows] START.cmd' }) | Select-Object -First 1
REM if (-not $start) { throw 'START missing after extract' }
REM $folder = $start.DirectoryName
REM foreach ($n in @('INSTALL.cmd','INSTALL.ps1','select-host.ps1','open-host.ps1')) {
REM   if (-not (Test-Path -LiteralPath (Join-Path $folder $n))) { throw ('missing ' + $n) }
REM }
REM if (-not (Test-Path -LiteralPath (Join-Path $folder '.agents\skills\work-intake\SKILL.md'))) { throw 'missing skill' }
REM Write-Host ('Extracted to: ' + $folder)
REM if ($env:WI_EXTRACT_ONLY -eq '1') { exit 0 }
REM Start-Process -FilePath $start.FullName -WorkingDirectory $folder
###END###
