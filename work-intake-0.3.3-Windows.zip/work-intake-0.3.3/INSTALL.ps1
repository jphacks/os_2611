﻿param([ValidateSet('codex','claude','gemini','both')][string]$HostName = 'codex')
$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot '.agents\skills\work-intake\SKILL.md'
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Incomplete package: extract the whole ZIP.' }
$expectedHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$content = [IO.File]::ReadAllText($source)
if ($content -notmatch '(?m)^name: work-intake$' -or $content -notmatch '(?m)^description: ') { throw 'Invalid release skill.' }
if (-not $env:USERPROFILE) { throw 'USERPROFILE is not set.' }
$hosts = if ($HostName -eq 'both') { @('codex','claude') } else { @($HostName) }
foreach ($targetHost in $hosts) {
    $parent = if ($targetHost -in @('codex','gemini')) { Join-Path $env:USERPROFILE '.agents\skills' } else { Join-Path $env:USERPROFILE '.claude\skills' }
    $dest = Join-Path $parent 'work-intake'
    if ((Test-Path -LiteralPath $parent) -and ((Get-Item -LiteralPath $parent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Blocked: linked parent $parent" }
    if ((Test-Path -LiteralPath $dest) -and ((Get-Item -LiteralPath $dest -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Blocked: linked target $dest" }
    $existing = Test-Path -LiteralPath $dest
    if ($existing) {
        if (-not (Test-Path -LiteralPath $dest -PathType Container)) { throw "Blocked: target is not a directory: $dest" }
        $oldSkill = Join-Path $dest 'SKILL.md'
        $oldValid = (Test-Path -LiteralPath $oldSkill -PathType Leaf) -and -not ((Get-Item -LiteralPath $oldSkill -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)
        if ($oldValid) {
            $oldText = [IO.File]::ReadAllText($oldSkill)
            $oldValid = $oldText.StartsWith('---') -and $oldText -match '(?m)^name: work-intake$' -and $oldText -match '(?m)^description: '
            $oldHash = (Get-FileHash -LiteralPath $oldSkill -Algorithm SHA256).Hash
            if ($oldValid -and $oldHash -eq $expectedHash -and @((Get-ChildItem -LiteralPath $dest -Force -Recurse)).Count -eq 1) {
                Write-Host "CURRENT ${targetHost}: 0.3.3 exact content verified."
                continue
            }
            $version = if ($oldText -match 'Work Intake 0\.3\.3') { '0.3.3 modified' } elseif ($oldText -match 'Work Intake 0\.3\.2') { '0.3.2' } elseif ($oldText -match 'Work Intake 0\.3\.1') { '0.3.1' } elseif ($oldText -match 'Work Intake 0\.3') { '0.3' } elseif ($oldText -match 'Work Intake 0\.2|work\.py|intake\.py') { '0.2.x' } else { 'unknown' }
            Write-Host "EXISTING ${targetHost}: $version; SHA-256 $oldHash."
        } else { Write-Host "EXISTING ${targetHost}: incomplete or unknown directory." }
        $answer = Read-Host 'Replace this directory after making a complete backup? [y/N]'
        if ($answer -notin @('y','Y','yes','YES')) { Write-Host "UNCHANGED $targetHost"; exit 1 }
    }
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $stage = Join-Path $parent ('.work-intake-stage-' + [guid]::NewGuid().ToString('N'))
    $backup = Join-Path $parent ('.work-intake-backup-' + [guid]::NewGuid().ToString('N'))
    $moved = $false
    try {
        [IO.Directory]::CreateDirectory($stage) | Out-Null
        Copy-Item -LiteralPath $source -Destination (Join-Path $stage 'SKILL.md') -ErrorAction Stop
        if ((Get-FileHash -LiteralPath (Join-Path $stage 'SKILL.md') -Algorithm SHA256).Hash -ne $expectedHash) { throw 'Staging verification failed.' }
        if ($existing) { [IO.Directory]::Move($dest,$backup); $moved = $true }
        [IO.Directory]::Move($stage,$dest)
        if ((Get-FileHash -LiteralPath (Join-Path $dest 'SKILL.md') -Algorithm SHA256).Hash -ne $expectedHash) { throw 'Installed bytes failed verification.' }
        if ($existing) { Write-Host "UPGRADED ${targetHost}: 0.3.3 verified. Backup: $backup" }
        else { Write-Host "INSTALLED ${targetHost}: 0.3.3 verified at $dest" }
    } catch {
        if (Test-Path -LiteralPath $dest) { [IO.Directory]::Move($dest, (Join-Path $parent ('.work-intake-failed-' + [guid]::NewGuid().ToString('N')))) }
        if ($moved -and (Test-Path -LiteralPath $backup)) { [IO.Directory]::Move($backup,$dest) }
        throw
    } finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    }
}
Write-Host 'Open a new host session and explicitly invoke work-intake to start.'
