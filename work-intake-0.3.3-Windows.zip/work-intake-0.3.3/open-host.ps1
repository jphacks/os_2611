﻿param([ValidateSet('codex','claude','gemini')][string]$HostName = 'codex')
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

# The Windows display language decides later replies.
# CurrentUICulture is unreliable: after the console switches to UTF-8 it can fall back to en-US on a Japanese Windows.
# The user language list is the keyboard preference, not the display language.
$languageTag = $null
foreach ($name in @('PreferredUILanguages', 'MachinePreferredUILanguages')) {
  if (-not $languageTag) {
    try {
      $value = (Get-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -Name $name -ErrorAction Stop).$name
      if ($value) { $languageTag = [string](@($value)[0]) }
    } catch { }
  }
}
if (-not $languageTag) { $languageTag = [Globalization.CultureInfo]::InstalledUICulture.Name }
if (-not $languageTag) { $languageTag = 'en' }
$language = $languageTag.Split('-')[0].ToLowerInvariant()
$displayName = switch ($language) {
  'zh' { '中国語' }
  'ja' { '日本語' }
  'ko' { '韓国語' }
  default { $languageTag }
}
switch ($language) {
  'zh' { $task = '请启动 Work Intake。利用你实际能访问的相关上下文了解我，核实历史信息时效性及项目状态，允许多个项目并行。必要时调查真实学校、公司、机构及工作环境；区分事实和推测，发现适合我的 AI 使用机会，优先使用已有能力。没有可访问记忆就直说，只问必要问题。未经我选择和授权不要安装新工具。' }
  'ja' { $task = 'Work Intake を開始してください。実際にアクセスできる関連情報を使い、過去の情報の時期と各プロジェクトの現在の状態を確かめ、複数のプロジェクトを並行して扱ってください。必要なら実際の学校、会社、機関や職場について調べ、事実と推測を分けて AI の活用機会を探し、既存の機能を優先してください。記憶にアクセスできなければそう伝え、必要なことだけ質問してください。私が選んで許可するまで新しいツールを導入しないでください。' }
  'ko' { $task = 'Work Intake를 시작해 주세요. 실제로 접근 가능한 관련 맥락을 활용하고, 과거 정보의 시점과 각 프로젝트의 현재 상태를 확인하며 여러 프로젝트를 함께 고려해 주세요. 필요하면 실제 학교, 회사, 기관과 업무 환경을 조사하고 사실과 추측을 구분해 AI 활용 기회를 찾되 기존 기능을 우선 사용해 주세요. 접근 가능한 기억이 없으면 알려 주고 필요한 질문만 해 주세요. 제가 선택하고 허락하기 전에는 새 도구를 설치하지 마세요.' }
  default { $task = 'Start Work Intake. Use only relevant context you can actually access; check the age of past information and the current status of each project, allowing parallel projects. When useful, research my real school, company, organization or work setting. Separate fact from inference, find practical AI opportunities and prefer capabilities I already have. If memory is unavailable, say so and ask only what is necessary. Do not install new tools without my choice and authorization.' }
}
switch ($language) {
  'zh' { $follow = ' 在我改用其他语言前，整个任务中你写的分析、进度、提问、建议和最终答复都使用中文；工具原始输出保持原样。' }
  'ja' { $follow = ' 私が別の言語を使うまで、作業中の説明、進捗、質問、提案、最終回答は日本語で書いてください。ツールの元の出力は変更しないでください。' }
  'ko' { $follow = ' 제가 다른 언어로 바꾸기 전까지 작업 중 설명, 진행 상황, 질문, 제안, 최종 답변을 모두 한국어로 작성해 주세요. 도구의 원본 출력은 그대로 두세요.' }
  default { $follow = ' Use the language I use in this conversation for your explanations, progress, questions, recommendations, and final answer; leave raw tool output unchanged.' }
}
$prompt = "最初の案内です。Work Intake を始めます。この案内のあと、説明、進捗、質問、提案、最終回答は $displayName（$languageTag）で続けてください。あとから別の言語を指定したら、その言語を優先してください。`r`n$task$follow"
$loginHelp = switch ($language) {
  'zh' { '如果 Claude 显示 Login expired，请在 Claude 窗口输入 /login，完成登录后继续。' }
  'ja' { 'Claude に Login expired と表示されたら、Claude の画面で /login と入力してログインし直してください。' }
  'ko' { 'Claude에 Login expired가 표시되면 Claude 창에서 /login을 입력하고 다시 로그인해 주세요.' }
  default { 'If Claude shows Login expired, enter /login in the Claude window and sign in again.' }
}

# Keep the starting message on the clipboard so every route below ends with Ctrl+V -> Send.
$copied = $false
try { Set-Clipboard -Value $prompt; $copied = $true } catch { }

Write-Host ''
Write-Host '開始メッセージ:'
Write-Host ('Windows の表示言語: ' + $languageTag)
Write-Host $prompt
if ($copied) { Write-Host '(クリップボードにコピーしました。入力欄が空なら Ctrl+V を押してください。)' }
Write-Host ''
if ($HostName -eq 'claude') {
  $claudeProtocol = (Test-Path 'Registry::HKEY_CURRENT_USER\Software\Classes\claude') -or
                    (Test-Path 'Registry::HKEY_CLASSES_ROOT\claude')
  $claudeDesktop = $null
  try {
    $claudeDesktop = Get-StartApps -ErrorAction Stop |
      Where-Object { $_.Name -match '^Claude( Desktop)?$' } | Select-Object -First 1
  } catch { }
  if ($claudeProtocol -and $claudeDesktop) {
    try {
      Start-Process -FilePath ('claude://code/new?q=' + [Uri]::EscapeDataString($prompt)) -ErrorAction Stop
      Write-Host 'Claude Desktop の Code に下書きを入れました。Code タブ、ローカルのセッション、Work Intake Skill を確認してから Send を押してください。'
      exit 0
    } catch {
      Write-Host ('Claude Desktop Code の起動要求に失敗しました: ' + $_.Exception.Message)
    }
  }
}
if ($HostName -ne 'codex') {
  $cli = Get-Command $HostName -ErrorAction SilentlyContinue | Where-Object { $_.CommandType -in @('Application','ExternalScript') } | Select-Object -First 1
  if (-not $cli) { Write-Host "$HostName コマンドがありません。インストールしただけではチャットは開きません。"; exit 2 }
  $workDir = [Environment]::GetFolderPath('UserProfile').Replace("'", "''")
  $executable = $cli.Source.Replace("'", "''")
  $escaped = $prompt.Replace("'", "''")
  $arguments = if ($HostName -eq 'gemini') { "-i '$escaped'" } else { "'$escaped'" }
  $command = "`$ErrorActionPreference = 'Stop'; try { Set-Location -LiteralPath '$workDir'; & '$executable' $arguments; if (`$LASTEXITCODE -ne 0) { Write-Host ('CLI 終了コード ' + `$LASTEXITCODE); Read-Host 'Enter を押すと起動状態を表示します'; exit 2 } } catch { [Console]::Error.WriteLine(`$_.Exception.Message); Read-Host 'Enter を押すと起動状態を表示します'; exit 2 }"
  $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
  try {
    Write-Host "$HostName の対話ウィンドウを要求しています。ログインや起動エラーを確認してください。"
    if ($HostName -eq 'claude') { Write-Host $loginHelp }
    if ($HostName -eq 'gemini') { Write-Host 'Gemini がサインインを求めたら、新しいウィンドウで完了してください。この起動プログラムは認証を確認していません。' }
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded) -ErrorAction Stop
    Write-Host "CLI の起動要求を送りました。新しいウィンドウで $HostName のチャットと Work Intake Skill を確認してください。"
    exit 0
  } catch {
    Write-Host ("$HostName のチャットを起動できませんでした: " + $_.Exception.Message)
    exit 2
  }
}
Write-Host 'Codex が開かない場合: Windows のスタートメニューから ChatGPT/Codex を開き、Codex に切り替えて新しいチャットを作り、上のメッセージを貼り付けてください。'
Write-Host ''

# What is installed on this PC?
$protocolKnown = (Test-Path -LiteralPath 'Registry::HKEY_CURRENT_USER\Software\Classes\codex') -or
                 (Test-Path -LiteralPath 'Registry::HKEY_CLASSES_ROOT\codex')
$desktopApp = $null
try {
  $desktopApp = Get-StartApps -ErrorAction Stop |
    Where-Object { $_.AppID -eq 'OpenAI.Codex_2p2nqsd0c76g0!App' -or $_.Name -match '^(OpenAI )?Codex$' } |
    Select-Object -First 1
} catch { }
$cli = Get-Command codex -ErrorAction SilentlyContinue | Select-Object -First 1

# 1) Codex desktop app: open a new chat with the message already filled in.
if ($protocolKnown -or $desktopApp) {
  try {
    Start-Process -FilePath ('codex://new?prompt=' + [Uri]::EscapeDataString($prompt)) -ErrorAction Stop
    Write-Host 'Windows は codex:// の起動要求を受け付けました。Codex が実際に開いたか確認してください。下書きは自動送信されません。Send を押してください。'
    exit 0
  } catch {
    Write-Host ('codex:// の起動に失敗しました: ' + $_.Exception.Message)
  }
}

# 2) Desktop app without a working link: open the app itself; the message is on the clipboard.
if ($desktopApp) {
  try {
    Start-Process -FilePath ('shell:AppsFolder\' + $desktopApp.AppID) -ErrorAction Stop
    Write-Host ($desktopApp.Name + ' を開きました。Codex に切り替え、新しいチャットで Ctrl+V して Send を押してください。Codex が実際に開いたか確認してください。')
    exit 0
  } catch {
    Write-Host ($desktopApp.Name + ' を開けませんでした: ' + $_.Exception.Message)
  }
}

# 3) Codex CLI: start a session in a new window with the message, so the work begins right away.
if ($cli) {
  $workDir = [Environment]::GetFolderPath('UserProfile')
  $escaped = $prompt.Replace("'", "''")
  $command = "Set-Location -LiteralPath '$($workDir.Replace("'", "''"))'; codex '$escaped'"
  $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
  try {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encoded) -ErrorAction Stop
    Write-Host 'Codex CLI を新しいウィンドウで開始しました。Codex が実際に開いたか確認してください。'
    exit 0
  } catch {
    Write-Host ('Codex CLI を開始できませんでした: ' + $_.Exception.Message)
  }
}

Write-Host 'この PC に Codex デスクトップアプリ、codex:// の関連付け、Codex CLI が見つかりませんでした。'
exit 2
