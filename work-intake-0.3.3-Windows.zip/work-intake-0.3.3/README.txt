Work Intake 0.3.3 Windows

[Windows] START.cmd を押してください。ZIP の中から押しても、このファイルが ZIP を展開してから起動します。
展開先は %USERPROFILE%\WorkIntake です。
Mac 用の起動ファイルは入っていません。
