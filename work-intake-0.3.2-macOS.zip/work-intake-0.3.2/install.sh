#!/bin/sh
# User-scope installer; no runtime dependencies beyond POSIX utilities.
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE="$BASE/.agents/skills/work-intake/SKILL.md"
[ -f "$SOURCE" ] || { echo 'Incomplete package: extract the whole ZIP.' >&2; exit 1; }
MODE=${1:-codex}
case "$MODE" in codex|claude|gemini|both) ;; *) echo 'Usage: sh install.sh [codex|claude|gemini|both]' >&2; exit 2;; esac
: "${HOME:?HOME is required}"
case "$MODE" in codex) HOSTS=codex;; claude) HOSTS=claude;; gemini) HOSTS=gemini;; both) HOSTS='codex claude';; esac
txn_active=0
rollback() {
  if [ "$txn_active" -eq 1 ]; then
    if [ -n "$backup" ] && [ -d "$backup" ]; then
      if [ -e "$dest" ]; then mv "$dest" "$parent/.work-intake-failed.$$" || true; fi
      mv "$backup" "$dest" || true
    fi
    if [ -n "$stage" ] && [ -d "$stage" ]; then rm -f "$stage/SKILL.md"; rmdir "$stage" || true; fi
  fi
}
trap rollback 0
trap 'exit 1' 1 2 3 15

is_valid() {
  [ -f "$1" ] && [ ! -L "$1" ] &&
  [ "$(sed -n '1p' "$1")" = '---' ] &&
  grep -qx 'name: work-intake' "$1" && grep -q '^description: ' "$1"
}
version_of() {
  if grep -q 'Work Intake 0\.3\.2' "$1"; then echo 0.3.2
  elif grep -q 'Work Intake 0\.3\.1' "$1"; then echo 0.3.1
  elif grep -q 'Work Intake 0\.3' "$1"; then echo 0.3
  elif grep -Eiq 'Work Intake 0\.2|work\.py|intake\.py' "$1"; then echo 0.2.x
  else echo unknown; fi
}
ask_upgrade() {
  # Replacement needs terminal consent; neither a pipe nor an environment flag can approve it.
  [ -t 0 ] || { echo 'BLOCKED: replacement requires interactive approval.' >&2; return 1; }
  printf 'Replace this directory? Its complete contents will be backed up. [y/N] '
  IFS= read -r answer || answer=''
  case "$answer" in y|Y|yes|YES) return 0;; *) return 1;; esac
}
install_one() {
  host=$1
  case "$host" in codex|gemini) parent="$HOME/.agents/skills";; claude) parent="$HOME/.claude/skills";; esac
  dest="$parent/work-intake"
  if [ -L "$parent" ] || [ -L "$dest" ]; then
    echo "BLOCKED $host: symlink in installation path." >&2; return 1
  fi
  if [ -e "$dest" ]; then
    if [ ! -d "$dest" ]; then echo "BLOCKED $host: target is not a directory." >&2; return 1; fi
    if is_valid "$dest/SKILL.md"; then
      if cmp -s "$SOURCE" "$dest/SKILL.md" &&
         [ "$(find "$dest" -type f | wc -l | tr -d ' ')" = 1 ] &&
         [ "$(find "$dest" -type d | wc -l | tr -d ' ')" = 1 ]; then
        echo "CURRENT $host: version 0.3.2, exact content verified."; return 0
      fi
      current=$(version_of "$dest/SKILL.md")
      echo "EXISTING $host: Work Intake $current; content differs or includes local files."
    else
      echo "EXISTING $host: incomplete or unrecognized skill; preserving it."
    fi
    if [ -f "$dest/SKILL.md" ] && [ ! -L "$dest/SKILL.md" ]; then
      if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$dest/SKILL.md" | sed 's/ .*$/ (SHA-256)/'
      elif command -v sha256sum >/dev/null 2>&1; then sha256sum "$dest/SKILL.md" | sed 's/ .*$/ (SHA-256)/'; fi
    fi
    if is_valid "$dest/SKILL.md" &&
       [ "$(find "$dest" -type f | wc -l | tr -d ' ')" = 1 ] &&
       [ "$(find "$dest" -type d | wc -l | tr -d ' ')" = 1 ] &&
       [ "$(version_of "$dest/SKILL.md")" != unknown ]; then
      # Known, uncustomized Work Intake version: backup and upgrade automatically.
      echo "AUTO-UPGRADE $host: verified Work Intake directory; backing up before replacement."
    else
      ask_upgrade || { echo "UNCHANGED $host: no replacement authorization."; return 3; }
    fi
  fi
  mkdir -p "$parent" || return 1
  stage=$(mktemp -d "$parent/.work-intake-stage.XXXXXX") || return 1
  backup=''
  if ! cp "$SOURCE" "$stage/SKILL.md" || ! cmp -s "$SOURCE" "$stage/SKILL.md" || ! is_valid "$stage/SKILL.md"; then
    rm -f "$stage/SKILL.md"; rmdir "$stage" 2>/dev/null || true
    echo "FAILED $host: could not prepare a valid skill." >&2; return 1
  fi
  if [ -e "$dest" ]; then
    backup=$(mktemp -d "$parent/.work-intake-backup.XXXXXX") || return 1
    rmdir "$backup"
    txn_active=1
    if ! mv "$dest" "$backup"; then rm -f "$stage/SKILL.md"; rmdir "$stage"; return 1; fi
  else
    txn_active=1
  fi
  if ! mv "$stage" "$dest"; then
    [ -z "$backup" ] || mv "$backup" "$dest"
    echo "FAILED $host: prior directory restored." >&2; return 1
  fi
  if ! cmp -s "$SOURCE" "$dest/SKILL.md" || ! is_valid "$dest/SKILL.md"; then
    mv "$dest" "$stage" || true
    [ -z "$backup" ] || mv "$backup" "$dest"
    echo "FAILED $host: verification failed; prior contents restored where possible." >&2; return 1
  fi
  txn_active=0
  if [ -n "$backup" ]; then echo "UPGRADED $host: 0.3.2 verified. Backup: $backup"
  else echo "INSTALLED $host: 0.3.2 verified at $dest"; fi
}
echo "Work Intake 0.3.2 — target: $MODE. No network or personal-file scan."
result=0
for host in $HOSTS; do install_one "$host" || result=1; done
if [ "$result" -eq 0 ]; then echo 'Open a new host session and explicitly invoke work-intake to start.'; fi
exit "$result"
