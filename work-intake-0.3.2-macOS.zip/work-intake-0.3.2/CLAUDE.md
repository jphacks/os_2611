# Work Intake in Claude Code

For a user request to discover fitting AI capabilities, load `.claude/skills/work-intake/SKILL.md` (or the installed personal Skill) and use the current session's authorized tools. Do not assume Codex tools or memory are available. For repository development, edit `skill/SKILL.md` and rebuild the host copies.
