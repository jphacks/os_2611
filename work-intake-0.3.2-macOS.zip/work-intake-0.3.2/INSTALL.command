#!/bin/sh
cd "$(dirname "$0")" || exit 1
sh ./install.sh codex
result=$?
echo 'Press Enter to close / 終了するにはEnter / 按回车关闭'
read -r answer || true
exit "$result"
