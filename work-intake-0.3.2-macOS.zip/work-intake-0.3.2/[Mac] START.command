#!/bin/bash
cd "$(dirname "$0")" || exit 1
PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export PATH
for required in install.sh .agents/skills/work-intake/SKILL.md; do
  if [ ! -f "$required" ]; then
    echo 'Package files are missing. Unzip the whole package, then run [Mac] START from its extracted folder.'
    exit 1
  fi
done
hosts=()
labels=()
apps_dir=${WI_APPLICATIONS_DIR:-/Applications}
if open -Ra Codex >/dev/null 2>&1 ||
   [ -d "$apps_dir/Codex.app" ] ||
   command -v codex >/dev/null 2>&1; then
  hosts+=(codex); labels+=('Codex')
fi
if command -v claude >/dev/null 2>&1; then hosts+=(claude); labels+=('Claude Code'); fi
if command -v gemini >/dev/null 2>&1; then hosts+=(gemini); labels+=('Gemini CLI'); fi
count=${#hosts[@]}
if [ "$count" -eq 0 ]; then
  echo 'No supported AI host detected. Install/sign in to Codex, Claude Code or Gemini CLI, then run START again.'
  exit 2
fi
selected=0
if [ "$count" -eq 1 ]; then
  echo "One detected host candidate: ${labels[0]}. Launch and Skill loading still need confirmation."
else
  echo "Work Intake - $count available AI hosts:"
  for ((i=0; i<count; i++)); do echo "[$((i+1))] ${labels[i]}"; done
  echo "Press 1-$count now; after 15 seconds [1] ${labels[0]} is selected."
  deadline=$((SECONDS+15))
  while [ "$SECONDS" -lt "$deadline" ]; do
    remaining=$((deadline-SECONDS))
    echo "Selecting [1] in $remaining seconds..."
    key=''
    if IFS= read -r -n 1 -t 1 key; then
      if [[ "$key" =~ ^[1-3]$ ]] && [ "$key" -le "$count" ]; then
        selected=$((key-1))
        break
      fi
      echo 'Invalid number. The countdown continues.'
    elif [ ! -t 0 ]; then
      sleep 1
    fi
  done
fi
target=${hosts[selected]}
echo "Selected ${labels[selected]}."
install_status=0
if ! sh ./install.sh "$target"; then
  install_status=1
  echo 'Skill installation or upgrade did not complete; existing Skill files remain unchanged.'
fi
if [ "$install_status" -ne 0 ] && [ "$target" != codex ]; then
  echo 'The new Skill is not installed; the chat was not launched as Work Intake.'
  exit 1
fi
# Prefer the primary macOS user language; do not parse arbitrary words from defaults output.
# WORK_INTAKE_LANG is an optional explicit override for multilingual Macs.
if [[ "${WORK_INTAKE_LANG:-}" =~ ^(ja|zh|ko|en)([-_][A-Za-z0-9]+)*$ ]]; then
  language=${WORK_INTAKE_LANG:0:2}
else
  primary_language=$(defaults read -g AppleLanguages 2>/dev/null | awk -F '"' '/"[A-Za-z][A-Za-z]([-_][A-Za-z0-9]+)*"/ { print $2; exit }')
  if [ -z "$primary_language" ]; then
    primary_language=$(defaults read -g AppleLanguages 2>/dev/null | awk '/^[[:space:]]*[a-z][a-z]([-_][A-Za-z0-9]+)*,?[[:space:]]*$/ {gsub(/[ ,]/, ""); print; exit}')
  fi
  language=${primary_language:0:2}
fi
echo "macOS conversation language: ${language:-en}"
case "$language" in
  zh) prompt='请启动 Work Intake。利用你实际能访问的相关上下文了解我，核实历史信息时效性及项目状态，允许多个项目并行。必要时调查真实学校、公司、机构及工作环境；区分事实和推测，发现适合我的 AI 使用机会，优先使用已有能力。没有可访问记忆就直说，只问必要问题。未经我选择和授权不要安装新工具。' ;;
  ja) prompt='Work Intake を開始してください。実際にアクセスできる関連情報を使い、過去の情報の時期と各プロジェクトの現在の状態を確かめ、複数のプロジェクトを並行して扱ってください。必要なら実際の学校、会社、機関や職場について調べ、事実と推測を分けて AI の活用機会を探し、既存の機能を優先してください。記憶にアクセスできなければそう伝え、必要なことだけ質問してください。私が選んで許可するまで新しいツールを導入しないでください。' ;;
  ko) prompt='Work Intake를 시작해 주세요. 실제로 접근 가능한 관련 맥락을 활용하고, 과거 정보의 시점과 각 프로젝트의 현재 상태를 확인하며 여러 프로젝트를 함께 고려해 주세요. 필요하면 실제 학교, 회사, 기관과 업무 환경을 조사하고 사실과 추측을 구분해 AI 활용 기회를 찾되 기존 기능을 우선 사용해 주세요. 접근 가능한 기억이 없으면 알려 주고 필요한 질문만 해 주세요. 제가 선택하고 허락하기 전에는 새 도구를 설치하지 마세요.' ;;
  *) prompt='Start Work Intake. Use only relevant context you can actually access; check the age of past information and each project’s status, allowing parallel projects. When useful, research my real school, company, organization or work setting. Separate fact from inference, find practical AI opportunities and prefer capabilities I already have. If memory is unavailable, say so and ask only what is necessary. Do not install new tools without my choice and authorization.' ;;
esac
# Keep conversation language consistent with the detected macOS UI language.
case "$language" in
  zh) prompt="$prompt 在我改用其他语言前，工作过程中的说明、进度、提问、建议和最终答复都使用中文；工具原始输出保持原样。" ;;
  ja) prompt="$prompt 私が別の言語を使うまで、作業中の説明、進捗、質問、提案、最終回答は日本語で書いてください。ツールの元の出力は変更しないでください。" ;;
  ko) prompt="$prompt 제가 다른 언어로 바꾸기 전까지 작업 중 설명, 진행 상황, 질문, 제안, 최종 답변을 모두 한국어로 작성해 주세요. 도구의 원본 출력은 그대로 두세요." ;;
  *) prompt="$prompt Use the language I use in this conversation for explanations, progress, questions, recommendations, and final answers; leave raw tool output unchanged." ;;
esac
printf '%s' "$prompt" | pbcopy 2>/dev/null || echo 'Clipboard unavailable; copy the message shown below.'
echo "Starting message: $prompt"
launch_status=$install_status
if [ "$target" = claude ] || [ "$target" = gemini ]; then
  # These are official interactive CLI forms. The terminal is the actual chat UI.
  cd "$HOME" || exit 2
  echo "Starting ${labels[selected]} with the initial message automatically (no paste or Enter required)..."
  if [ "$target" = claude ]; then claude "$prompt"; else gemini -i "$prompt"; fi
  result=$?
  if [ "$result" -ne 0 ]; then echo "${labels[selected]} ended with an error ($result); no chat was verified."; fi
  exit "$result"
fi
# A Mac can accept a URL without showing a window; request the app separately.
app_requested=1
if open -a Codex >/dev/null 2>&1 ||
   { [ -d "$apps_dir/Codex.app" ] && open "$apps_dir/Codex.app" >/dev/null 2>&1; }; then app_requested=0; fi
encoded=$(printf '%s' "$prompt" | od -An -v -tx1 | tr -s '[:space:]' '\n' | sed -n '/./s/^/%/p' | tr -d '\n')
if [ "$app_requested" -eq 0 ] && open "codex://new?prompt=$encoded" >/dev/null 2>&1; then
  echo 'Mac accepted the Codex new-chat request. Confirm its window, then press Send.'
elif [ "$app_requested" -eq 0 ]; then
  echo 'The Codex new-chat link failed. The app was requested; switch to Codex, create a chat and paste the message.'
  launch_status=2
else
  if command -v codex >/dev/null 2>&1; then
    echo 'Codex Desktop not found. Starting Codex CLI with the initial message...'
    cd "$HOME" || exit 2
    codex "$prompt"
    exit $?
  fi
  echo 'Codex Desktop could not be opened. Install or sign in to Codex and retry.'
  launch_status=2
fi
if [ "$install_status" -ne 0 ]; then echo 'The new Work Intake Skill was not installed; the app launch does not prove Skill activation.'; fi
exit "$launch_status"
