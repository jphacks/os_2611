Work Intake 0.3.2 — macOS standalone package

This is a platform-specific distribution, not a merged Windows/Mac ZIP.
Source: work-intake-0.3.2-mac-only-reviewed.zip

Unzip the entire archive before running.
Double-click [Mac] START.command. It requires macOS, and the installed AI host may request login/permission.

This package contains only this platform's launcher and installer. The core Work Intake Skill is copied without modification from the stated source. Do not mix files from the other platform or previous ZIPs.
No Windows or macOS end-to-end execution has been verified in this Linux build environment.
