# Work Intake development and in-project use

When the user asks to **use** Work Intake, read `.agents/skills/work-intake/SKILL.md` and apply its host-native protocol to authorized task materials. When asked to **develop** this repository, edit `skill/SKILL.md`, run `python3 build_release.py` to generate identical host copies, and run the tests. Never require the former `work.py`, Python runtime, SQLite database, or questionnaire from an end user. This repository is not automatically their work project. Do not mistake installation for host invocation or functional success.
